from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS 
from flask import jsonify

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgres+psycopg2://postgres:root@localhost:5432/toDoApp'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)
CORS(app)

"""class ContactInfo(db.Model):
	__tablename__= "Contacts"
	id = db.Column(db.Integer, primary_key = True)
	FirstName = db.Column(db.String)
	LastName = db.Column(db.String)
	Email = db.Column(db.String)
	Phone = db.Column(db.String)"""

class TaskList(db.Model):
	__tablename__= "TaskList"
	id = db.Column(db.Integer, primary_key = True)
	name = db.Column(db.String)
	
	def __init__(self, name):
		self.name = name
		print('data created')
	
	"""def __init__(self, FirstName, LastName, Email, Phone):
		self.FirstName = FirstName
		self.LastName = LastName
		self.Email = Email
		self.Phone = Phone
		print('data created')"""

class Task(db.Model):
	__tablename__= "Task"
	id = db.Column(db.Integer, primary_key = True)
	text = db.Column(db.String)
	list_id = db.Column(db.Integer)
	Completed = db.Column(db.Boolean)

	def __init__(self,text,list_id):
		self.text = text
		self.list_id = list_id
		self.Completed = False
		print("object is created")


@app.route('/TaskList', methods = ['POST'])
def postContacts():
	data = request.get_json()
	name = data["name"]
	tL = TaskList(name)
	db.session.add(tL)
	db.session.commit()
	return jsonify(message ="task list created"), 201

"""@app.route('/ContactInfo', methods = ['POST'])
def postContacts():
	data = request.get_json()
	FirstName = data["FirstName"]
	LastName = data["LastName"]
	Email = data["Email"]
	Phone = data["Phone"]
	
	Con = ContactInfo(FirstName,LastName,Email,Phone)
	db.session.add(Con)
	db.session.commit()
	return jsonify(message ="task list created"), 201"""

@app.route('/TaskList')
def getContacts():
	taskLists =TaskList.query.all()
	task_List = []
	for tasklist in taskLists:
		t = {}
		t["Id"] = tasklist.id
		t["name"] = tasklist.name
		task_List.append(t)
	return jsonify(list = task_List)

"""@app.route('/ContactInfo')
def getContacts():
	contacts =ContactInfo.query.all()
	Contact_List = []
	for con in contacts:
		c = {}
		c["FirstName"] = con.FirstName
		c["LastName"] = con.LastName
		c["Email"] = con.Email
		c["Phone"] = con.Phone
		Contact_List.append(c)
	return jsonify(list = Contact_List)"""

@app.route('/Task', methods = ['POST'])
def create_Tasks():
	data = request.get_json()
	text = data["text"]
	list_id = data["list_id"]
	ts = Task(text,list_id)
	db.session.add(ts)
	db.session.commit()
	return jsonify(message = "task is created"), 201

@app.route('/Task')
def get_taskList():
	task_lists_id = request.args.get('task_list')
	tasks = Task.query.filter_by(list_id = task_lists_id)
	ListOfTasks = []
	for ts in tasks:
		t = {}
		t["id"] = ts.id
		t["text"] = ts.text
		t["list_id"] = ts.list_id
		t["Completed"] = ts.Completed
		ListOfTasks.append(t)
	return jsonify(list = ListOfTasks)

@app.route('/Task/<id>', methods = ['PUT'])
def update_task(id):
	task = Task.query.filter_by(id = id).first()
	task.Completed = not(task.Completed)
	db.session.add(task)
	db.session.commit()
	return jsonify(message = "data updated", task_id = task.id , task_completed = task.Completed), 201

@app.route('/Task/<id>' , methods = ['DELETE'])
def delete_task(id):
	task = Task.query.filter_by(id = id).first()
	db.session.delete(task)
	db.session.commit()
	return jsonify(message = "delete task")

@app.route('/')
def helloword():
	return 'hello world'

if __name__=='__main__':
	db.create_all()
	app.run(debug=True)